public class ParkingRecord {

    private boolean found;
    private int carsMoved;
    private int pushCount;
    private int popCount;
    private int comparisonCount;
    private int loopCount;

    public ParkingRecord() {

        found = false;
        carsMoved = 0;
        pushCount = 0;
        popCount = 0;
        comparisonCount = 0;
        loopCount = 0;
    }

    public boolean isFound() {
        return found;
    }

    public void setFound(boolean found) {
        this.found = found;
    }

    public int getCarsMoved() {
        return carsMoved;
    }

    public void incrementCarsMoved() {
        carsMoved++;
    }

    public int getPushCount() {
        return pushCount;
    }

    public void incrementPush() {
        pushCount++;
    }

    public int getPopCount() {
        return popCount;
    }

    public void incrementPop() {
        popCount++;
    }

    public int getComparisonCount() {
        return comparisonCount;
    }

    public void incrementComparison() {
        comparisonCount++;
    }

    // Loop Count
    public int getLoopCount() {
        return loopCount;
    }

    public void incrementLoop() {
        loopCount++;
    }
}

