import java.util.Stack;

public class StackManager {

    private Stack<Vehicle> parkingStack;
    private Stack<Vehicle> temporaryStack;

    public StackManager() {
        parkingStack = new Stack<>();
        temporaryStack = new Stack<>();
    }

    // =========================================
    // เพิ่มรถเข้า Parking Stack
    // =========================================
    public boolean addVehicle(Vehicle vehicle) {

        // ตรวจสอบทะเบียนซ้ำ
        for (Vehicle car : parkingStack) {

            if (car.getLicensePlate()
                    .equalsIgnoreCase(vehicle.getLicensePlate())) {

                return false;
            }
        }

        parkingStack.push(vehicle);

        return true;
    }

    // =========================================
    // Algorithm A : Iteration
    // Pop -> Compare -> Temp -> Restore
    // =========================================
    public ParkingRecord removeVehicle(String target) {

        ParkingRecord record = new ParkingRecord();

        // ค้นหารถ
        while (!parkingStack.isEmpty()) {

            record.incrementLoop();

            Vehicle current = parkingStack.pop();
            record.incrementPop();

            record.incrementComparison();

            // พบรถเป้าหมาย
            if (current.getLicensePlate()
                    .equalsIgnoreCase(target)) {

                record.setFound(true);
                break;
            }

            // ไม่ใช่เป้าหมาย → ย้ายไป Temp
            temporaryStack.push(current);

            record.incrementPush();
            record.incrementCarsMoved();
        }

        // Restore รถกลับเข้า Parking Stack
        while (!temporaryStack.isEmpty()) {

            record.incrementLoop();

            Vehicle current = temporaryStack.pop();

            parkingStack.push(current);

            record.incrementPush();
        }

        return record;
    }

    // =========================================
    // Algorithm B : Recursive
    // Pop -> Compare -> Recursive -> Push Back
    // =========================================
    public ParkingRecord removeVehicleRecursive(String target) {

        ParkingRecord record = new ParkingRecord();

        removeRecursive(target, record);

        return record;
    }

    // Recursive Function
    private boolean removeRecursive(
            String target,
            ParkingRecord record) {

        // Base Case : Stack ว่าง
        if (parkingStack.isEmpty()) {
            return false;
        }

        record.incrementLoop();

        // Pop รถด้านบน
        Vehicle current = parkingStack.pop();

        record.incrementPop();

        // เปรียบเทียบทะเบียน
        record.incrementComparison();

        // พบรถเป้าหมาย
        if (current.getLicensePlate()
                .equalsIgnoreCase(target)) {

            record.setFound(true);

            return true;
        }

        // Recursive Call
        boolean found =
                removeRecursive(target, record);

        // นำรถเดิมกลับเข้า Stack
        parkingStack.push(current);

        record.incrementPush();

        if (!found) {
            record.incrementCarsMoved();
        }

        return found;
    }

    // =========================================
    // แสดงสถานะ Parking Stack
    // =========================================
    public void displayStack() {

        System.out.println("\n===== Parking Stack =====");

        if (parkingStack.isEmpty()) {

            System.out.println("Stack is empty.");
            return;
        }

        System.out.println("TOP");

        for (int i = parkingStack.size() - 1;
             i >= 0;
             i--) {

            System.out.println(parkingStack.get(i));
        }

        System.out.println("BOTTOM");
    }

    // =========================================
    // ตรวจสอบ Stack ว่าง
    // =========================================
    public boolean isEmpty() {
        return parkingStack.isEmpty();
    }
}

