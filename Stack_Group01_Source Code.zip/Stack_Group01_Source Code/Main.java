import java.util.Scanner;

public class Main {

    static Scanner scanner = new Scanner(System.in);
    static StackManager manager = new StackManager();

    public static void main(String[] args) {

        while (true) {

            System.out.println("\n==============================");
            System.out.println("     PARKING STACK SYSTEM");
            System.out.println("==============================");
            System.out.println("1. Add Vehicle");
            System.out.println("2. Remove Vehicle");
            System.out.println("3. Display Stack");
            System.out.println("4. Exit");
            System.out.println("5. TC08 - Test 50,000 Vehicles");
            System.out.println("6. Performance Test");
            System.out.println("==============================");

            System.out.print("Choose: ");

            String choice = scanner.nextLine().trim();

            switch (choice) {

                case "1":
                    addVehicle();
                    break;

                case "2":
                    removeVehicle();
                    break;

                case "3":
                    manager.displayStack();
                    break;

                case "4":
                    System.out.println("Program End.");
                    scanner.close();
                    return;

                case "5":
                    test50000();
                    break;

                case "6":
                    performanceTest();
                    break;

                default:
                    System.out.println(
                            "Invalid menu. Please choose 1-6.");
            }
        }
    }

    // =====================================================
    // ADD VEHICLE
    // =====================================================
    public static void addVehicle() {

        System.out.println("\n===== Add Vehicle =====");

        String licensePlate =
                inputNotEmpty("License Plate: ");

        String ownerName =
                inputNotEmpty("Owner Name: ");

        String entryTime =
                inputNotEmpty("Entry Time: ");

        String vehicleType =
                inputNotEmpty("Vehicle Type: ");

        Vehicle vehicle = new Vehicle(
                licensePlate,
                ownerName,
                entryTime,
                vehicleType
        );

        if (manager.addVehicle(vehicle)) {

            System.out.println(
                    "Vehicle added successfully.");

        } else {

            System.out.println(
                    "License Plate already exists.");
        }
    }

    // =====================================================
    // REMOVE VEHICLE
    // เลือก Algorithm A หรือ B
    // =====================================================
    public static void removeVehicle() {

        System.out.println("\n===== Remove Vehicle =====");

        if (manager.isEmpty()) {

            System.out.println(
                    "Parking Stack is empty.");

            return;
        }

        String target =
                inputNotEmpty("Target License Plate: ");

        System.out.println("\nChoose Algorithm");
        System.out.println("A. Iterative");
        System.out.println("B. Recursive");
        System.out.print("Choose: ");

        String algorithm =
                scanner.nextLine().trim();

        ParkingRecord record;

        long start = System.nanoTime();

        if (algorithm.equalsIgnoreCase("A")) {

            record =
                    manager.removeVehicle(target);

        } else if (algorithm.equalsIgnoreCase("B")) {

            record =
                    manager.removeVehicleRecursive(target);

        } else {

            System.out.println(
                    "Invalid Algorithm.");

            return;
        }

        long end = System.nanoTime();

        printResult(
                target,
                record,
                end - start
        );

        manager.displayStack();
    }

    // =====================================================
    // แสดงผลการค้นหา
    // =====================================================
    public static void printResult(
            String target,
            ParkingRecord record,
            long executionTime) {

        System.out.println("\n===== Result =====");

        if (record.isFound()) {

            System.out.println(
                    "Target Found : " + target);

        } else {

            System.out.println(
                    "Target Not Found : " + target);
        }

        System.out.println(
                "Cars Moved : "
                + record.getCarsMoved());

        System.out.println(
                "Push : "
                + record.getPushCount());

        System.out.println(
                "Pop : "
                + record.getPopCount());

        System.out.println(
                "Comparison : "
                + record.getComparisonCount());

        System.out.println(
                "Loop Count : "
                + record.getLoopCount());

        System.out.println(
                "Execution Time : "
                + executionTime + " ns");
    }

    // =====================================================
    // TC08 : 50,000 Vehicles
    // =====================================================
    public static void test50000() {

        System.out.println(
                "\n===== TC08: 50,000 Vehicles =====");

        StackManager testManager =
                new StackManager();

        System.out.println(
                "Creating 50,000 vehicles...");

        for (int i = 1; i <= 50000; i++) {

            Vehicle vehicle =
                    new Vehicle(
                            String.format(
                                    "CAR%05d", i),
                            "Owner" + i,
                            "10.00",
                            "Car"
                    );

            testManager.addVehicle(vehicle);
        }

        System.out.println(
                "Added : 50,000 vehicles");

        long start =
                System.nanoTime();

        ParkingRecord record =
                testManager.removeVehicle(
                        "CAR50000");

        long end =
                System.nanoTime();

        System.out.println(
                "\n===== Result =====");

        if (record.isFound()) {

            System.out.println(
                    "Target Found : CAR50000");

        } else {

            System.out.println(
                    "Target Not Found : CAR50000");
        }

        System.out.println(
                "Cars Moved : "
                + record.getCarsMoved());

        System.out.println(
                "Push : "
                + record.getPushCount());

        System.out.println(
                "Pop : "
                + record.getPopCount());

        System.out.println(
                "Comparison : "
                + record.getComparisonCount());

        System.out.println(
                "Loop Count : "
                + record.getLoopCount());

        System.out.println(
                "Execution Time : "
                + (end - start) + " ns");

        System.out.println(
                "===== TC08 Complete =====");
    }

    // =====================================================
    // PERFORMANCE TEST
    // A และ B
    // 100 / 1,000 / 10,000 / 50,000
    // 5 Rounds
    // =====================================================
    public static void performanceTest() {

        System.out.println(
                "\n==========================================");

        System.out.println(
                "     PERFORMANCE TEST - A vs B");

        System.out.println(
                "==========================================");

        int[] sizes = {
                100,
                1000,
                10000,
                50000
        };

        for (int n : sizes) {

            performanceForAlgorithm(n, "A");

            performanceForAlgorithm(n, "B");
        }
    }

    // =====================================================
    // Performance ของแต่ละ Algorithm
    // =====================================================
    public static void performanceForAlgorithm(
            int n,
            String algorithm) {

        System.out.println(
                "\n========== "
                + "N = "
                + n
                + " | Algorithm "
                + algorithm
                + " ==========");

        long totalTime = 0;
        long totalPush = 0;
        long totalPop = 0;
        long totalComparison = 0;
        long totalLoop = 0;

        for (int round = 1; round <= 5; round++) {

            StackManager testManager =
                    new StackManager();

            // สร้างข้อมูล
            for (int i = 1; i <= n; i++) {

                Vehicle vehicle =
                        new Vehicle(
                                String.format(
                                        "CAR%05d", i),
                                "Owner" + i,
                                "10.00",
                                "Car"
                        );

                testManager.addVehicle(vehicle);
            }

            /*
             * ใช้ CAR00001 เป็น Target
             *
             * เพราะ Stack เป็น LIFO
             * จึงต้อง Pop รถด้านบนออก
             * จำนวนมากก่อนจะถึง Target
             */
            String target =
                    "CAR00001";

            long start =
                    System.nanoTime();

            ParkingRecord record;

            if (algorithm.equals("A")) {

                record =
                        testManager.removeVehicle(
                                target);

            } else {

                record =
                        testManager.removeVehicleRecursive(
                                target);
            }

            long end =
                    System.nanoTime();

            long time =
                    end - start;

            totalTime += time;
            totalPush +=
                    record.getPushCount();

            totalPop +=
                    record.getPopCount();

            totalComparison +=
                    record.getComparisonCount();

            totalLoop +=
                    record.getLoopCount();

            System.out.println(
                    "Round "
                    + round
                    + " | Time: "
                    + time
                    + " ns"
                    + " | Push: "
                    + record.getPushCount()
                    + " | Pop: "
                    + record.getPopCount()
                    + " | Comparison: "
                    + record.getComparisonCount()
                    + " | Loop: "
                    + record.getLoopCount());
        }

        System.out.println(
                "------------------------------------------");

        System.out.println(
                "Average Time : "
                + (totalTime / 5)
                + " ns");

        System.out.println(
                "Average Push : "
                + (totalPush / 5));

        System.out.println(
                "Average Pop : "
                + (totalPop / 5));

        System.out.println(
                "Average Comparison : "
                + (totalComparison / 5));

        System.out.println(
                "Average Loop Count : "
                + (totalLoop / 5));
    }

    // =====================================================
    // ตรวจสอบ Input ไม่ให้ว่าง
    // =====================================================
    public static String inputNotEmpty(
            String message) {

        while (true) {

            System.out.print(message);

            String input =
                    scanner.nextLine().trim();

            if (!input.isEmpty()) {

                return input;
            }

            System.out.println(
                    "Input cannot be empty. Please try again.");
        }
    }
}
